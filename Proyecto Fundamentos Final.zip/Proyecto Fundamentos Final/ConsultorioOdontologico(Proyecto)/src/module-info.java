/**
 * 
 */
/**
 * 
 */
module ConsultorioOdontologico {
	requires java.desktop;
}