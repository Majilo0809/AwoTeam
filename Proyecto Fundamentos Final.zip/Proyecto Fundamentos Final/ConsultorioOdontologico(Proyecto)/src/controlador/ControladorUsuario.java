package controlador;

import modelo.dao.UsuarioDao;
import modelo.dto.Usuario;
import vista.VistaUsuario;

import java.util.ArrayList;
import java.util.List;

public class ControladorUsuario {

    private UsuarioDao usuarioDao;
    private VistaUsuario vistaUsuario;

    public ControladorUsuario(VistaUsuario vistaUsuario) {
        this.usuarioDao = new UsuarioDao(); // Inicializa la conexión al DAO
        this.vistaUsuario = vistaUsuario; // Asigna la vista
        this.vistaUsuario.setVisible(true); // Hace visible la vista de usuario
    }

    // Método para buscar un usuario por rol e identificación
    public Usuario buscarUsuarioPorRolYIdentificacion(String rol, String identificacion) {
        return usuarioDao.buscarUsuarioPorRolYIdentificacion(rol, identificacion);
    }

    // Método para agregar un nuevo usuario
    public void agregarUsuario(Usuario usuario) {
        if (!existeUsuario(usuario.getRol(), usuario.getIdentificacion())) {
            usuarioDao.agregarUsuario(usuario);
        } else {
            // Podrías agregar una lógica para manejar cuando el usuario ya existe, por ejemplo, mostrar un mensaje
            System.out.println("El usuario ya existe.");
        }
    }

    // Método para buscar usuarios de un rol específico
    public List<Usuario> buscarUsuariosPorRol(String rol) {
        return usuarioDao.buscarUsuariosPorRol(rol);
    }

    // Método para listar todos los usuarios (sin importar su rol)
    public List<Usuario> listarTodosUsuarios() {
        List<Usuario> todosUsuarios = new ArrayList<>();
        todosUsuarios.addAll(usuarioDao.buscarUsuariosPorRol("Paciente"));
        todosUsuarios.addAll(usuarioDao.buscarUsuariosPorRol("Odontologo"));
        todosUsuarios.addAll(usuarioDao.buscarUsuariosPorRol("Auxiliar"));
        todosUsuarios.addAll(usuarioDao.buscarUsuariosPorRol("Administrador"));
        return todosUsuarios;
    }

    // Método para eliminar un usuario por su identificación
    public void eliminarUsuario(String identificacion) {
        if (usuarioDao.buscarUsuarioPorIdentificacion(identificacion) != null) {
            usuarioDao.eliminarUsuario(identificacion);
        } else {
            // Lógica si el usuario no se encuentra
            System.out.println("Usuario no encontrado.");
        }
    }

    // Método para actualizar los datos de un usuario existente
    public void actualizarUsuario(Usuario usuario) {
        if (usuarioDao.buscarUsuarioPorIdentificacion(usuario.getIdentificacion()) != null) {
            usuarioDao.agregarUsuario(usuario);
        } else {
            // Lógica si el usuario no existe para actualizar
            System.out.println("Usuario no encontrado para actualizar.");
        }
    }

    // Método para verificar si un usuario ya existe (por rol e identificación)
    public boolean existeUsuario(String rol, String identificacion) {
        Usuario usuario = buscarUsuarioPorRolYIdentificacion(rol, identificacion);
        return usuario != null;
    }
}
