package controlador;

import vista.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import main.MainAgenda;

public class ControladorPrincipal implements ActionListener {
    private VistaPrincipal vista;

    public ControladorPrincipal(VistaPrincipal vista) {
        this.vista = vista;
        this.vista.btnAgenda.addActionListener(this);
        this.vista.btnHistoriaC.addActionListener(this);
        this.vista.btnSalir.addActionListener(this);
        this.vista.btnActores.addActionListener(this);
        this.vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(vista.btnHistoriaC)) {
            // Abrir la vista de Historia Clínica
            VistaHistoriaClinica vistaHistoriaClinica = new VistaHistoriaClinica();
            new ControladorHistoriaClinica(vistaHistoriaClinica);
        }

        if (e.getSource().equals(vista.btnAgenda)) {
            // Abrir el MainAgenda para seleccionar entre agendar o consultar
            MainAgenda mainAgenda = new MainAgenda();
            mainAgenda.setVisible(true);
            vista.setVisible(true); // Cerrar la ventana principal
        }

        if (e.getSource().equals(vista.btnActores)) {
            // Crear la vista de Actores y su controlador
            new ControladorUsuario(new VistaUsuario());
        }

        if (e.getSource().equals(vista.btnSalir)) {
            // Salir de la aplicación
            System.exit(0);
        }
    }
}
