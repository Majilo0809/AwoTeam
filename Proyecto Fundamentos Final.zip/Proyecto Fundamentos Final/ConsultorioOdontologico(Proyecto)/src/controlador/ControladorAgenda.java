package controlador;

import modelo.dao.AgendaDao;
import modelo.dto.Agenda;
import vista.VistaAgenda;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class ControladorAgenda {

    private AgendaDao agendaDao;
    private VistaAgenda vista;

    public ControladorAgenda(VistaAgenda vista) {
        this.vista = vista;
        this.agendaDao = new AgendaDao();
    }

    // Método para consultar la agenda de un odontólogo
    public void consultarAgendaPorOdontologo(String odontologo) {
        ArrayList<Agenda> agendas = agendaDao.readAll();
        DefaultTableModel modelo = (DefaultTableModel) vista.tableAgenda.getModel();
        modelo.setRowCount(0);  // Limpiar la tabla antes de llenarla

        // Rellenar la tabla con las agendas filtradas por odontólogo
        for (Agenda agenda : agendas) {
            // Asegurarse de que el odontólogo se compara sin importar mayúsculas o minúsculas
            if (agenda.getOdontologo().equalsIgnoreCase(odontologo)) {
                modelo.addRow(new Object[]{
                    agenda.getHora(),
                    agenda.getOdontologo(),
                    agenda.getPaciente(),
                    agenda.getDia(),
                    agenda.getConsultorio()
                });
            }
        }

        // Si no se encuentra el odontólogo, mostrar mensaje
        if (modelo.getRowCount() == 0) {
            vista.showMessage("No se encontraron citas para el odontólogo: " + odontologo);
        }
    }
}