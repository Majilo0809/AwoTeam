package controlador;

import modelo.dao.AgendaDao;
import modelo.dto.Agenda;
import vista.VistaCita;
import javax.swing.table.DefaultTableModel;

public class ControladorCita {

    private AgendaDao agendaDao;
    private VistaCita vista;

    public ControladorCita(VistaCita vista) {
        this.vista = vista;
        this.agendaDao = new AgendaDao();
    }

    // Método para agendar una nueva cita
    public void agendarCita(String odontologo, String paciente, String fecha, String hora, String consultorio) {
        int codigoCita = (int) (Math.random() * 1000); // Generar código de cita aleatorio
        Agenda nuevaAgenda = new Agenda(odontologo, paciente, codigoCita, fecha, hora, consultorio);

        // Agregar la nueva agenda al DAO
        agendaDao.create(nuevaAgenda);

        // Actualizar la tabla en la vista
        actualizarTabla();
    }

    // Método para actualizar la tabla en la vista
    public void actualizarTabla() {
        DefaultTableModel modelo = (DefaultTableModel) vista.tableAgenda.getModel();
        modelo.setRowCount(0);  // Limpiar la tabla

        // Rellenar la tabla con todas las citas
        for (Agenda agenda : agendaDao.readAll()) {
            modelo.addRow(new Object[]{
                agenda.getHora(),
                agenda.getOdontologo(),
                agenda.getPaciente(),
                agenda.getDia(),
                agenda.getConsultorio()
            });
        }
    }
}