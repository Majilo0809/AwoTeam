package controlador;

import vista.VistaInforme;
import modelo.dao.InformeDao;
import modelo.dto.Informe;
import java.util.List;

public class ControladorInforme {

    private VistaInforme vista;
    private InformeDao dao;

    // Constructor
    public ControladorInforme() {
        this.dao = new InformeDao();  // Inicializa el DAO
        List<Informe> informes = dao.obtenerInformes();  // Obtiene los informes desde el DAO
        this.vista = new VistaInforme(informes);  // Inicializa la vista con los informes
        this.vista.setVisible(true);  // Muestra la vista
    }
}
