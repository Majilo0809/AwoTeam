package controlador;

import modelo.dao.HistoriaClinicaDao;
import modelo.dto.HistoriaClinica;
import vista.VistaHistoriaClinica;

public class ControladorHistoriaClinica {

    private HistoriaClinicaDao historiaClinicaDao;
    private VistaHistoriaClinica vistaHistoriaClinica;

    public ControladorHistoriaClinica(VistaHistoriaClinica vistaHistoriaClinica) {
        this.historiaClinicaDao = new HistoriaClinicaDao();
        this.vistaHistoriaClinica = vistaHistoriaClinica;
        this.vistaHistoriaClinica.setVisible(true);  // para hacerla visible
    }

    // Método para agregar historia clínica
    public void agregarHistoriaClinica(HistoriaClinica historiaClinica) {
        historiaClinicaDao.agregarHistoriaClinica(historiaClinica);
    }

    // Método para buscar una historia clínica por identificación del paciente
    public HistoriaClinica buscarHistoriaClinica(String identificacionPaciente) {
        return historiaClinicaDao.buscarHistoriaClinicaPorIdentificacion(identificacionPaciente);
    }

    // Método para listar todas las historias clínicas
    public void listarHistoriasClinicas() {
        vistaHistoriaClinica.mostrarHistoriasClinicas(historiaClinicaDao.listarTodasHistoriasClinicas());
    }
}
