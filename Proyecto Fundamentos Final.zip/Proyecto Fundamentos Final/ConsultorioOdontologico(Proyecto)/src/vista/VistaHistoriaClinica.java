package vista;

import controlador.ControladorHistoriaClinica;
import modelo.dto.HistoriaClinica;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class VistaHistoriaClinica extends JFrame {
    private static final long serialVersionUID = 1L;
    private ControladorHistoriaClinica controlador;
    private JTextField identificacionField;
    private JTextArea resultadoArea;
    private JButton buscarBtn, agregarHistoriaBtn;

    public VistaHistoriaClinica() {
        controlador = new ControladorHistoriaClinica(this);
        configurarInterfaz();
    }

    private void configurarInterfaz() {
        setTitle("Historia Clínica");
        setSize(734, 585);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel identificacionLabel = new JLabel("Identificación del Paciente:");
        identificacionLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        identificacionLabel.setBounds(20, 30, 200, 30);
        getContentPane().add(identificacionLabel);

        identificacionField = new JTextField();
        identificacionField.setFont(new Font("Tahoma", Font.PLAIN, 15));
        identificacionField.setBounds(220, 30, 200, 30);
        getContentPane().add(identificacionField);

        buscarBtn = new JButton("Buscar Historia");
        buscarBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        buscarBtn.setBounds(430, 30, 200, 30);
        getContentPane().add(buscarBtn);

        resultadoArea = new JTextArea();
        resultadoArea.setBounds(20, 120, 540, 300);
        resultadoArea.setEditable(false);
        getContentPane().add(resultadoArea);

        agregarHistoriaBtn = new JButton("Agregar Historia");
        agregarHistoriaBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        agregarHistoriaBtn.setBounds(430, 430, 200, 30);
        getContentPane().add(agregarHistoriaBtn);

        buscarBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarHistoriaClinica();
            }
        });

        agregarHistoriaBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirAgregarHistoriaDialog();
            }
        });
    }

    private void abrirAgregarHistoriaDialog() {
        VAgregarHistoriaClinica agregarHistoriaDialog = new VAgregarHistoriaClinica(this, controlador);
        agregarHistoriaDialog.setVisible(true);
    }

    private void buscarHistoriaClinica() {
        String identificacionPaciente = identificacionField.getText();
        HistoriaClinica historiaClinica = controlador.buscarHistoriaClinica(identificacionPaciente);

        if (historiaClinica != null) {
            resultadoArea.setText(
                "Diagnóstico: " + historiaClinica.getDiagnostico() + "\n" +
                "Tratamiento: " + historiaClinica.getTratamiento() + "\n" +
                "Fecha: " + historiaClinica.getFecha() + "\n" +
                "Observaciones: " + historiaClinica.getObservaciones()
            );
        } else {
            resultadoArea.setText("Historia clínica no encontrada.");
        }
    }

    public void mostrarHistoriasClinicas(List<HistoriaClinica> historiasClinicas) {
        StringBuilder texto = new StringBuilder();
        for (HistoriaClinica historia : historiasClinicas) {
            texto.append("Paciente ID: ").append(historia.getIdentificacionPaciente()).append("\n");
            texto.append("Diagnóstico: ").append(historia.getDiagnostico()).append("\n");
            texto.append("Tratamiento: ").append(historia.getTratamiento()).append("\n");
            texto.append("Fecha: ").append(historia.getFecha()).append("\n");
            texto.append("Observaciones: ").append(historia.getObservaciones()).append("\n\n");
        }
        resultadoArea.setText(texto.toString());
    }


}
