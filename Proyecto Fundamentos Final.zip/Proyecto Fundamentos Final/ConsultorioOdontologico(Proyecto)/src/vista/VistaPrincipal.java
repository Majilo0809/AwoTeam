package vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import controlador.ControladorInforme;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VistaPrincipal extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    public JButton btnHistoriaC;
    public JButton btnAgenda;
    public JButton btnSalir;
    public JButton btnActores;
    public JButton btnInforme;

    /**
     * Create the frame.
     */
    public VistaPrincipal() {
    	this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 640, 472);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblNewLabel_1 = new JLabel("ODONTOLOGIA AWO AWO");
        lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Lenovo\\OneDrive\\FISICA\\Ortonova3.9.png"));
        lblNewLabel_1.setBounds(133, 61, 407, 223);
        contentPane.add(lblNewLabel_1);
        
        btnHistoriaC = new JButton("VER HISTORIA CLINICA");
        btnHistoriaC.setHorizontalAlignment(SwingConstants.LEFT);
        btnHistoriaC.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnHistoriaC.setBounds(15, 294, 244, 41);
        contentPane.add(btnHistoriaC);
        
        btnAgenda = new JButton("VER AGENDA");
        btnAgenda.setHorizontalAlignment(SwingConstants.LEFT);
        btnAgenda.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnAgenda.setBounds(15, 384, 244, 41);
        contentPane.add(btnAgenda);
        
        btnSalir = new JButton("SALIR");
        btnSalir.setForeground(Color.RED);
        btnSalir.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnSalir.setBounds(431, 384, 185, 41);
        contentPane.add(btnSalir);
        
        btnActores = new JButton("VER ROLES ACTIVOS");
        btnActores.setHorizontalAlignment(SwingConstants.LEFT);
        btnActores.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnActores.setBounds(15, 338, 244, 41);
        contentPane.add(btnActores);
        
        JLabel lblNewLabel = new JLabel("BIENVENIDO A ORTONOVA ORTODONCIA");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
        lblNewLabel.setBounds(15, 9, 601, 61);
        contentPane.add(lblNewLabel);
        
        JSeparator separator = new JSeparator();
        separator.setBounds(10, 64, 606, 16);
        contentPane.add(separator);
        
        btnInforme = new JButton("VER INFORMES");
        btnInforme.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Crear el controlador para los informes
                new ControladorInforme();
            }
        });
        btnInforme.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnInforme.setBounds(413, 306, 203, 29);
        contentPane.add(btnInforme);
    }
}
