package vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import controlador.ControladorAgenda;
import modelo.dto.Agenda;

import java.awt.Font;

public class VistaAgenda extends JFrame {

    private JPanel contentPane;
    public JTextField textFOdontologo;
    public JTable tableAgenda;
    private ControladorAgenda controladorAgenda;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                VistaAgenda frame = new VistaAgenda();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public VistaAgenda() {
        setTitle("Consulta Agenda");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 800, 700);
        contentPane = new JPanel();
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        controladorAgenda = new ControladorAgenda(this);

        JLabel lblNewLabel = new JLabel("Consultar Agenda");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 28));
        lblNewLabel.setBounds(10, 22, 250, 66);
        contentPane.add(lblNewLabel);

        JLabel lblOdontologo = new JLabel("Odontologo");
        lblOdontologo.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblOdontologo.setBounds(10, 110, 178, 18);
        contentPane.add(lblOdontologo);

        textFOdontologo = new JTextField();
        textFOdontologo.setFont(new Font("Tahoma", Font.PLAIN, 10));
        textFOdontologo.setBounds(156, 112, 173, 20);
        contentPane.add(textFOdontologo);
        textFOdontologo.setColumns(10);

        JButton btnConsultar = new JButton("Consultar");
        btnConsultar.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btnConsultar.setBounds(482, 110, 130, 30);
        contentPane.add(btnConsultar);

        btnConsultar.addActionListener(e -> {
            String odontologo = textFOdontologo.getText();
            controladorAgenda.consultarAgendaPorOdontologo(odontologo);
        });

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 160, 739, 466);
        contentPane.add(scrollPane);

        tableAgenda = new JTable();
        tableAgenda.setModel(new DefaultTableModel(
                new Object[][] {},
                new String[] {"Hora", "Odontologo", "Paciente", "Día", "Consultorio"}
        ));
        scrollPane.setViewportView(tableAgenda);
    }

    // Método para mostrar un mensaje si no se encuentran citas
    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

	public void actualizarTabla(Agenda[] array) {
		// TODO Auto-generated method stub
		
	}
}