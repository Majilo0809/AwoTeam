package vista;

import controlador.ControladorHistoriaClinica;
import modelo.dto.HistoriaClinica;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VAgregarHistoriaClinica extends JDialog {
    private ControladorHistoriaClinica controlador;
    private JTextField identificacionField, diagnosticoField, tratamientoField, fechaField, observacionesField;
    private JButton agregarBtn, cancelarBtn;

    public VAgregarHistoriaClinica(JFrame parent, ControladorHistoriaClinica controlador) {
        super(parent, "Agregar Historia Clínica", true);
        this.controlador = controlador;
        setSize(660, 374);
        setLocationRelativeTo(parent);
        getContentPane().setLayout(null);

        // Campos para la historia clínica
        JLabel labelIdentificacion = new JLabel("Identificación del Paciente:");
        labelIdentificacion.setBounds(10, 37, 200, 25);
        getContentPane().add(labelIdentificacion);
        identificacionField = new JTextField();
        identificacionField.setBounds(220, 37, 200, 25);
        getContentPane().add(identificacionField);

        JLabel labelDiagnostico = new JLabel("Diagnóstico:");
        labelDiagnostico.setBounds(10, 80, 200, 25);
        getContentPane().add(labelDiagnostico);
        diagnosticoField = new JTextField();
        diagnosticoField.setBounds(220, 80, 200, 25);
        getContentPane().add(diagnosticoField);

        JLabel labelTratamiento = new JLabel("Tratamiento:");
        labelTratamiento.setBounds(10, 120, 200, 25);
        getContentPane().add(labelTratamiento);
        tratamientoField = new JTextField();
        tratamientoField.setBounds(220, 120, 200, 25);
        getContentPane().add(tratamientoField);

        JLabel labelFecha = new JLabel("Fecha:");
        labelFecha.setBounds(10, 160, 200, 25);
        getContentPane().add(labelFecha);
        fechaField = new JTextField();
        fechaField.setBounds(220, 160, 200, 25);
        getContentPane().add(fechaField);

        JLabel labelObservaciones = new JLabel("Observaciones:");
        labelObservaciones.setBounds(10, 200, 200, 25);
        getContentPane().add(labelObservaciones);
        observacionesField = new JTextField();
        observacionesField.setBounds(220, 200, 200, 25);
        getContentPane().add(observacionesField);

        // Botones
        agregarBtn = new JButton("Agregar");
        agregarBtn.setBounds(120, 250, 100, 30);
        getContentPane().add(agregarBtn);
        cancelarBtn = new JButton("Cancelar");
        cancelarBtn.setBounds(280, 250, 100, 30);
        getContentPane().add(cancelarBtn);

        agregarBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarHistoriaClinica();
            }
        });

        cancelarBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }

    private void agregarHistoriaClinica() {
        HistoriaClinica historiaClinica = new HistoriaClinica();
        historiaClinica.setIdentificacionPaciente(identificacionField.getText());
        historiaClinica.setDiagnostico(diagnosticoField.getText());
        historiaClinica.setTratamiento(tratamientoField.getText());
        historiaClinica.setFecha(fechaField.getText());
        historiaClinica.setObservaciones(observacionesField.getText());

        controlador.agregarHistoriaClinica(historiaClinica);
        JOptionPane.showMessageDialog(this, "Historia clínica agregada exitosamente.");
        dispose();
    }
}
