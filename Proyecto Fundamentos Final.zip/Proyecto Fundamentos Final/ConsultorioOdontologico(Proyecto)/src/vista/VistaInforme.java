package vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelo.dto.Informe;
import java.awt.*;
import java.util.List;

public class VistaInforme extends JFrame {

    private JTable tablaInformes;

    public VistaInforme(List<Informe> informes) {
        setTitle("Informe de Odontólogos");
        setSize(600, 400);
        setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Crear el modelo de la tabla
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Odontólogo");
        model.addColumn("Cantidad de Citas");

        // Agregar los informes a la tabla
        for (Informe informe : informes) {
            model.addRow(new Object[]{informe.getNombre(), informe.getCantidadCitas()});
        }

        // Crear la tabla
        tablaInformes = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(tablaInformes);
        add(scrollPane, BorderLayout.CENTER);
    }
}
