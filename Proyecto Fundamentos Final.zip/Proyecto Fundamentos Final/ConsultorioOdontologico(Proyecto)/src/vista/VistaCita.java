package vista;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import controlador.ControladorCita;

public class VistaCita extends JFrame {

    public JPanel contentPane;
    public JTextField textFOdontologo;
    public JTextField textFPaciente;
    public JTextField textFFecha;
    public JTextField textFHora;
    public JTextField textFConsultorio;
    public JTable tableAgenda;
    public JButton btnAgendar;

    private ControladorCita controladorCita;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    VistaCita frame = new VistaCita();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public VistaCita() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 775, 675);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        controladorCita = new ControladorCita(this);

        JLabel lblNewLabel = new JLabel("AGENDA DE CITAS");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 28));
        lblNewLabel.setBounds(10, 22, 250, 66);
        contentPane.add(lblNewLabel);

        JLabel lblOdontologo = new JLabel("Odontologo");
        lblOdontologo.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblOdontologo.setBounds(10, 110, 178, 18);
        contentPane.add(lblOdontologo);

        textFOdontologo = new JTextField();
        textFOdontologo.setFont(new Font("Tahoma", Font.PLAIN, 10));
        textFOdontologo.setBounds(156, 112, 173, 20);
        contentPane.add(textFOdontologo);
        textFOdontologo.setColumns(10);

        JLabel lblPaciente = new JLabel("Paciente");
        lblPaciente.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblPaciente.setBounds(10, 140, 178, 18);
        contentPane.add(lblPaciente);

        textFPaciente = new JTextField();
        textFPaciente.setFont(new Font("Tahoma", Font.PLAIN, 10));
        textFPaciente.setBounds(156, 140, 173, 20);
        contentPane.add(textFPaciente);
        textFPaciente.setColumns(10);

        JLabel lblFecha = new JLabel("Fecha");
        lblFecha.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblFecha.setBounds(10, 170, 178, 18);
        contentPane.add(lblFecha);

        textFFecha = new JTextField();
        textFFecha.setFont(new Font("Tahoma", Font.PLAIN, 10));
        textFFecha.setBounds(156, 170, 173, 20);
        contentPane.add(textFFecha);
        textFFecha.setColumns(10);

        JLabel lblHora = new JLabel("Hora");
        lblHora.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblHora.setBounds(10, 200, 178, 18);
        contentPane.add(lblHora);

        textFHora = new JTextField();
        textFHora.setFont(new Font("Tahoma", Font.PLAIN, 10));
        textFHora.setBounds(156, 200, 173, 20);
        contentPane.add(textFHora);
        textFHora.setColumns(10);

        JLabel lblConsultorio = new JLabel("Consultorio");
        lblConsultorio.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblConsultorio.setBounds(10, 230, 178, 18);
        contentPane.add(lblConsultorio);

        textFConsultorio = new JTextField();
        textFConsultorio.setFont(new Font("Tahoma", Font.PLAIN, 10));
        textFConsultorio.setBounds(156, 230, 173, 20);
        contentPane.add(textFConsultorio);
        textFConsultorio.setColumns(10);

        btnAgendar = new JButton("Agendar");
        btnAgendar.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btnAgendar.setBounds(482, 140, 130, 30);
        contentPane.add(btnAgendar);

        btnAgendar.addActionListener(e -> {
            String odontologo = textFOdontologo.getText();
            String paciente = textFPaciente.getText();
            String fecha = textFFecha.getText();
            String hora = textFHora.getText();
            String consultorio = textFConsultorio.getText();
            controladorCita.agendarCita(odontologo, paciente, fecha, hora, consultorio);
        });

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 285, 739, 316);
        contentPane.add(scrollPane);

        tableAgenda = new JTable();
        tableAgenda.setModel(new DefaultTableModel(
                new Object[][] {},
                new String[] {"Hora", "Odontologo", "Paciente", "Día", "Consultorio"}
        ));
        scrollPane.setViewportView(tableAgenda);
    }
}