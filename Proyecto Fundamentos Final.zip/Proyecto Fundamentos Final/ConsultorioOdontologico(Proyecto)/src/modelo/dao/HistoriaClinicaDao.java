package modelo.dao;

import modelo.dto.HistoriaClinica;
import java.util.ArrayList;
import java.util.List;

public class HistoriaClinicaDao {

    private List<HistoriaClinica> listaHistoriasClinicas;

    public HistoriaClinicaDao() {
        listaHistoriasClinicas = new ArrayList<>();
    }

    public void agregarHistoriaClinica(HistoriaClinica historiaClinica) {
        listaHistoriasClinicas.add(historiaClinica);
    }

    public HistoriaClinica buscarHistoriaClinicaPorIdentificacion(String identificacionPaciente) {
        for (HistoriaClinica historia : listaHistoriasClinicas) {
            if (historia.getIdentificacionPaciente().equals(identificacionPaciente)) {
                return historia;
            }
        }
        return null;
    }

    public List<HistoriaClinica> listarTodasHistoriasClinicas() {
        return listaHistoriasClinicas;
    }
}
