package modelo.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import modelo.dto.Auxiliar;

public class AuxiliarDao  {
	private ArrayList<Auxiliar> lista;
	private ObjectInputStream entrada;
	private ObjectOutputStream salida;
	private String archivo;
	
	public AuxiliarDao() {
		this.archivo = "agenda";
		File file = new File(archivo);
			if (file.isFile()) {				
				try {
					this.entrada = new ObjectInputStream(new FileInputStream(archivo));
					this.lista = (ArrayList<Auxiliar>) entrada.readObject();
					this.entrada.close();
				} catch (Exception e) {
					System.out.println(e.getMessage());
					guardar();
				}	
			} else {
				lista = new ArrayList<>();
			}
	}
	
	//Guarda en la capa de persistencia la lista
	private void guardar() {
		try {
			this.salida = new ObjectOutputStream(new FileOutputStream(archivo));
			this.salida.writeObject(lista);
			this.salida.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public boolean create(Auxiliar agenda) {
		lista.add(agenda);
		guardar();
		return true;
	}
	
	public Auxiliar read(int codigo) {
		for (Auxiliar auxiliar : lista) {
			if (auxiliar.getIdentificacion() == codigo) {
				return auxiliar;
			}
		}
		return null;
	}
	
	public Auxiliar update(int index, Auxiliar auxiliar) {
		lista.set(index, auxiliar);
		guardar();		
		return auxiliar;
	}
	
	public boolean delete(Auxiliar auxiliar) {
		lista.remove(auxiliar);
		guardar();
		return true;
	}
	
	public ArrayList<Auxiliar> readAll(){
		return lista;
	}
	
	public int buscarIndex(Auxiliar auxiliar) {
		return lista.indexOf(auxiliar);
	}
	
}

	
	