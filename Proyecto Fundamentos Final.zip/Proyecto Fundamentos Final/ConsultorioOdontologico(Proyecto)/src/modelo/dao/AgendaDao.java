package modelo.dao;

import modelo.dto.Agenda;
import java.util.ArrayList;

public class AgendaDao {

    private ArrayList<Agenda> agendas = new ArrayList<>();

    public AgendaDao() {
        // Agregar algunos datos predeterminados
        agendas.add(new Agenda("Perez", "Juan Perez", 1, "Lunes", "09:00", "Consultorio 1"));
        agendas.add(new Agenda("Lopez", "Ana Garcia", 2, "Martes", "10:00", "Consultorio 2"));
        agendas.add(new Agenda("Perez", "Luis Gomez", 3, "Lunes", "10:00", "Consultorio 1"));
    }

    public void create(Agenda agenda) {
        agendas.add(agenda);
    }

    public ArrayList<Agenda> readAll() {
        return agendas;
    }
}