package modelo.dao;

import java.util.ArrayList;
import java.util.List;

import modelo.dto.Informe;

public class InformeDao {

    // Método para obtener los informes
    public List<Informe> obtenerInformes() {
        List<Informe> informes = new ArrayList<>();
        informes.add(new Informe("Dr. Pérez", 2));
        informes.add(new Informe("Dr. López", 1));
        return informes;
    }
}