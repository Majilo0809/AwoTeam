package modelo.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import modelo.dto.Odontologo;

public class OdontologoDao {
	private ArrayList<Odontologo> lista;
	private ObjectInputStream entrada;
	private ObjectOutputStream salida;
	private String archivo;
	
	public OdontologoDao() {
		this.archivo = "cita";
		File file = new File(archivo);
			if (file.isFile()) {				
				try {
					this.entrada = new ObjectInputStream(new FileInputStream(archivo));
					this.lista = (ArrayList<Odontologo>) entrada.readObject();
					this.entrada.close();
				} catch (Exception e) {
					System.out.println(e.getMessage());
					guardar();
				}	
			} else {
				lista = new ArrayList<>();
			}
	}
	
	//Guarda en la capa de persistencia la lista
	private void guardar() {
		try {
			this.salida = new ObjectOutputStream(new FileOutputStream(archivo));
			this.salida.writeObject(lista);
			this.salida.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public boolean create(Odontologo odontologo) {
		lista.add(odontologo);
		guardar();
		return true;
	}
	
	public Odontologo read(int codigo) {
		for (Odontologo odontologo: lista) {
			if (odontologo.getIdentificacion() == codigo) {
				return odontologo;
			}
		}
		return null;
	}
	
	public Odontologo update(int index, Odontologo odontologo) {
		lista.set(index, odontologo);
		guardar();		
		return odontologo;
	}
	
	public boolean delete(Odontologo odontologo) {
		lista.remove(odontologo);
		guardar();
		return true;
	}
	
	public ArrayList<Odontologo> readAll(){
		return lista;
	}
	
	public int buscarIndex(Odontologo odontologo) {
		return lista.indexOf(odontologo);
	}
	
}

	
	