package modelo.dao;

import modelo.dto.Usuario;
import java.util.List;
import java.util.ArrayList;

public class UsuarioDao {
    // Simularemos la base de datos con una lista de usuarios
    private List<Usuario> usuarios = new ArrayList<>();

    // Método para agregar un nuevo usuario a la "base de datos"
    public void agregarUsuario(Usuario usuario) {
        usuarios.add(usuario);
        System.out.println("Usuario agregado: " + usuario.getIdentificacion());
    }

    // Método para buscar un usuario por su identificación
    public Usuario buscarUsuarioPorIdentificacion(String identificacion) {
        for (Usuario usuario : usuarios) {
            if (usuario.getIdentificacion().equals(identificacion)) {
                return usuario; // Si encontramos el usuario, lo retornamos
            }
        }
        return null; // Si no lo encontramos, retornamos null
    }

    // Método para buscar un usuario por rol y su identificación
    public Usuario buscarUsuarioPorRolYIdentificacion(String rol, String identificacion) {
        for (Usuario usuario : usuarios) {
            if (usuario.getRol().equals(rol) && usuario.getIdentificacion().equals(identificacion)) {
                return usuario; // Retorna el usuario si cumple con ambos criterios
            }
        }
        return null; // Retorna null si no encuentra coincidencias
    }

    // Método para actualizar un usuario en la "base de datos"
    public void actualizarUsuario(Usuario usuarioActualizado) {
        for (int i = 0; i < usuarios.size(); i++) {
            Usuario usuario = usuarios.get(i);
            if (usuario.getIdentificacion().equals(usuarioActualizado.getIdentificacion())) {
                // Actualiza la información del usuario
                usuarios.set(i, usuarioActualizado);
                System.out.println("Usuario actualizado: " + usuarioActualizado.getIdentificacion());
                return;
            }
        }
        System.out.println("Usuario no encontrado para actualizar.");
    }

    // Método para eliminar un usuario de la "base de datos"
    public void eliminarUsuario(String identificacion) {
        for (int i = 0; i < usuarios.size(); i++) {
            Usuario usuario = usuarios.get(i);
            if (usuario.getIdentificacion().equals(identificacion)) {
                usuarios.remove(i);
                System.out.println("Usuario eliminado: " + identificacion);
                return;
            }
        }
        System.out.println("Usuario no encontrado para eliminar.");
    }

    // Método para obtener todos los usuarios
    public List<Usuario> obtenerTodosUsuarios() {
        return usuarios; // Retorna la lista completa de usuarios
    }

    // Método para buscar usuarios por rol (no se ha mencionado en el contexto, pero puede ser útil)
    public List<Usuario> buscarUsuariosPorRol(String rol) {
        List<Usuario> usuariosPorRol = new ArrayList<>();
        for (Usuario usuario : usuarios) {
            if (usuario.getRol().equals(rol)) {
                usuariosPorRol.add(usuario);
            }
        }
        return usuariosPorRol;
    }
}
