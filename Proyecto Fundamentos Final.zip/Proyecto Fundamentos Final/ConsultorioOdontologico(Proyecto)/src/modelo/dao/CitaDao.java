package modelo.dao;

import modelo.dao.CitaDao;
import modelo.dto.Cita;

import java.util.ArrayList;
import java.util.List;

public class CitaDao {
    private List<Cita> citas;

    public CitaDao() {
        citas = new ArrayList<>();
    }

    public void agregarCita(Cita cita) {
        citas.add(cita);
    }

    public List<Cita> obtenerCitas() {
        return citas;
    }

    public List<Cita> obtenerCitasPorOdontologo(String odontologo) {
        List<Cita> citasFiltradas = new ArrayList<>();
        for (Cita cita : citas) {
            if (cita.getOdontologo().equalsIgnoreCase(odontologo)) {
                citasFiltradas.add(cita);
            }
        }
        return citasFiltradas;
    }
}