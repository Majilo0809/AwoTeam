package modelo.dto;

public class Agenda {
    private String odontologo;
    private String paciente;
    private int codigoCita;
    private String dia;
    private String hora;
    private String consultorio;

    public Agenda(String odontologo, String paciente, int codigoCita, String dia, String hora, String consultorio) {
        this.odontologo = odontologo;
        this.paciente = paciente;
        this.codigoCita = codigoCita;
        this.dia = dia;
        this.hora = hora;
        this.consultorio = consultorio;
    }

    public String getOdontologo() {
        return odontologo;
    }

    public void setOdontologo(String odontologo) {
        this.odontologo = odontologo;
    }

    public String getPaciente() {
        return paciente;
    }

    public void setPaciente(String paciente) {
        this.paciente = paciente;
    }

    public int getCodigoCita() {
        return codigoCita;
    }

    public void setCodigoCita(int codigoCita) {
        this.codigoCita = codigoCita;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getConsultorio() {
        return consultorio;
    }

    public void setConsultorio(String consultorio) {
        this.consultorio = consultorio;
    }
}