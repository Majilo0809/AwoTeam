package modelo.dto;

public class Informe {
    private String nombre;
    private int cantidadCitas;

    // Constructor
    public Informe(String nombre, int cantidadCitas) {
        this.nombre = nombre;
        this.cantidadCitas = cantidadCitas;
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public int getCantidadCitas() {
        return cantidadCitas;
    }
}