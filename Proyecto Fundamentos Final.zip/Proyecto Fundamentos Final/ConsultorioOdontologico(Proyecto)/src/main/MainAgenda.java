package main;

import vista.VistaAgenda;
import vista.VistaCita;
import javax.swing.*;

public class MainAgenda extends JFrame { // Asegúrate de que MainAgenda extienda JFrame

    public MainAgenda() {
        // Configuración de la ventana JFrame (título, tamaño, operación de cierre, etc.)
        super("Selección de opción");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 200);

        // Crear el panel y los botones
        JPanel panel = new JPanel();
        JButton btnAgendar = new JButton("Agendar Cita");
        JButton btnConsultar = new JButton("Consultar Agenda");

        // Acción para "Agendar Cita"
        btnAgendar.addActionListener(e -> {
            // Cerrar la ventana principal y abrir VistaCita
            setVisible(true);
            VistaCita vistaCita = new VistaCita();
            vistaCita.setVisible(true);
        });

        // Acción para "Consultar Agenda"
        btnConsultar.addActionListener(e -> {
            // Cerrar la ventana principal y abrir VistaAgenda
            setVisible(true);
            VistaAgenda vistaAgenda = new VistaAgenda();
            vistaAgenda.setVisible(true);
        });

        // Agregar los botones al panel y añadir el panel al JFrame
        panel.add(btnAgendar);
        panel.add(btnConsultar);
        add(panel);
    }

    public static void main(String[] args) {
        // Instanciar y mostrar MainAgenda
        MainAgenda mainAgenda = new MainAgenda();
        mainAgenda.setVisible(true); // Esto ahora es válido
    }
}
