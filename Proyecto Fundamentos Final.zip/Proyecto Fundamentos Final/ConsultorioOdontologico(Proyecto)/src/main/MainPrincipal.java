package main;

import vista.VistaPrincipal;
import controlador.ControladorPrincipal;

public class MainPrincipal {
    public static void main(String[] args) {
    	VistaPrincipal vistaPrincipal = new VistaPrincipal();
        ControladorPrincipal controladorPrincipal = new ControladorPrincipal(new VistaPrincipal());
    }
}

