/**
 * 
 */
/**
 * 
 */
module consultorioOdontologico {
	requires java.desktop;
}