package modelo.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import modelo.dto.Agenda;

public class AgendaDao  {
	private ArrayList<Agenda> lista;
	private ObjectInputStream entrada;
	private ObjectOutputStream salida;
	private String archivo;
	
	public AgendaDao() {
		this.archivo = "agenda";
		File file = new File(archivo);
			if (file.isFile()) {				
				try {
					this.entrada = new ObjectInputStream(new FileInputStream(archivo));
					this.lista = (ArrayList<Agenda>) entrada.readObject();
					this.entrada.close();
				} catch (Exception e) {
					System.out.println(e.getMessage());
					guardar();
				}	
			} else {
				lista = new ArrayList<>();
			}
	}
	
	//Guarda en la capa de persistencia la lista
	private void guardar() {
		try {
			this.salida = new ObjectOutputStream(new FileOutputStream(archivo));
			this.salida.writeObject(lista);
			this.salida.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public boolean create(Agenda agenda) {
		lista.add(agenda);
		guardar();
		return true;
	}
	
	public Agenda read(int codigo) {
		for (Agenda agenda : lista) {
			if (agenda.getCodigoCita() == codigo) {
				return agenda;
			}
		}
		return null;
	}
	
	public Agenda update(int index, Agenda agenda) {
		lista.set(index, agenda);
		guardar();		
		return agenda;
	}
	
	public boolean delete(Agenda agenda) {
		lista.remove(agenda);
		guardar();
		return true;
	}
	
	public ArrayList<Agenda> readAll(){
		return lista;
	}
	
	public int buscarIndex(Agenda agenda) {
		return lista.indexOf(agenda);
	}
	
}

	
	