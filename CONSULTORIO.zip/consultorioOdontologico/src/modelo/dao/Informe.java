package modelo.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import modelo.dto.Informe;

public class InformeDao {
	private ArrayList<Informe> lista;
	private ObjectInputStream entrada;
	private ObjectOutputStream salida;
	private String archivo;
	
	public InformeDao() {
		this.archivo = "cita";
		File file = new File(archivo);
			if (file.isFile()) {				
				try {
					this.entrada = new ObjectInputStream(new FileInputStream(archivo));
					this.lista = (ArrayList<Informe>) entrada.readObject();
					this.entrada.close();
				} catch (Exception e) {
					System.out.println(e.getMessage());
					guardar();
				}	
			} else {
				lista = new ArrayList<>();
			}
	}
	
	//Guarda en la capa de persistencia la lista
	private void guardar() {
		try {
			this.salida = new ObjectOutputStream(new FileOutputStream(archivo));
			this.salida.writeObject(lista);
			this.salida.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public boolean create(Informe informe) {
		lista.add(informe);
		guardar();
		return true;
	}
	
	public Informe read(int codigo) {
		for (Informe informe : lista) {
			if (informe.getCodigoInforme() == codigo) {
				return informe;
			}
		}
		return null;
	}
	
	public Informe update(int index, Informe informe) {
		lista.set(index, informe);
		guardar();		
		return informe;
	}
	
	public boolean delete(Informe informe) {
		lista.remove(informe);
		guardar();
		return true;
	}
	
	public ArrayList<Informe> readAll(){
		return lista;
	}
	
	public int buscarIndex(Informe informe) {
		return lista.indexOf(informe);
	}
	
}

	
	