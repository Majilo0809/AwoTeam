package modelo.dto;

import java.io.Serializable;

public class Agenda implements Serializable {
	
	private String odontologo;
	private int dia;
	private String paciente;
	private int codigoCita;
	private int hora;
	private int consultorio;
	public String getOdontologo() {
		return odontologo;
	}
	public void setOdontologo(String odontologo) {
		this.odontologo = odontologo;
	}
	public int getdia() {
		return dia;
	}
	public void setdia(int dia) {
		this.dia = dia;
	}
	public String getPaciente() {
		return paciente;
	}
	public void setPaciente(String paciente) {
		this.paciente = paciente;
	}
	public int getCodigoCita() {
		return codigoCita;
	}
	public void setCodigoCita(int codigoCita) {
		this.codigoCita = codigoCita;
	}
	
	public int getHora() {
		return hora;
	}
	public void setHora(int hora) {
		this.hora = hora;
	}
	public int getConsultorio() {
		return consultorio;
	}
	public void setConsultorio(int consultorio) {
		this.consultorio = consultorio;
	}
	
	

}
