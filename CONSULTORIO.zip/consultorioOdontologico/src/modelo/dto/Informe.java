package modelo.dto;

import java.io.Serializable;
import java.util.ArrayList;

public class Informe implements Serializable  {
	
	private ArrayList<Odontologo> listaOdontologos;
	private ArrayList<Auxiliares> listaAuxiliares;
	private ArrayList<Pacientes> listaPacientes;
	private ArrayList<PacientesAtendidosPorOdontologos> listaPacientesAtendidosPorOdontologos;
	private int año;
	private int mes;
	public ArrayList<Odontologo> getListaOdontologos() {
		return listaOdontologos;
	}
	public void setListaOdontologos(ArrayList<Odontologo> listaOdontologos) {
		this.listaOdontologos = listaOdontologos;
	}
	public ArrayList<Auxiliares> getListaAuxiliares() {
		return listaAuxiliares;
	}
	public void setListaAuxiliares(ArrayList<Auxiliares> listaAuxiliares) {
		this.listaAuxiliares = listaAuxiliares;
	}
	public ArrayList<Pacientes> getListaPacientes() {
		return listaPacientes;
	}
	public void setListaPacientes(ArrayList<Pacientes> listaPacientes) {
		this.listaPacientes = listaPacientes;
	}
	public ArrayList<PacientesAtendidosPorOdontologos> getListaPacientesAtendidosPorOdontologos() {
		return listaPacientesAtendidosPorOdontologos;
	}
	public void setListaPacientesAtendidosPorOdontologos(
			ArrayList<PacientesAtendidosPorOdontologos> listaPacientesAtendidosPorOdontologos) {
		this.listaPacientesAtendidosPorOdontologos = listaPacientesAtendidosPorOdontologos;
	}
	public int getAño() {
		return año;
	}
	public void setAño(int año) {
		this.año = año;
	}
	public int getMes() {
		return mes;
	}
	public void setMes(int mes) {
		this.mes = mes;
	}
	
	
	
}
