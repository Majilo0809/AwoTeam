package vista;

public class VistaInforme {

}
