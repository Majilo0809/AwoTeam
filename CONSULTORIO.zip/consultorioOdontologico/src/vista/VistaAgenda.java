package vista;

public class VistaAgenda {

}
