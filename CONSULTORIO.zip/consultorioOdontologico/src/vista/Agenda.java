package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Agenda extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFOdontologo;
	private JTextField textFPaciente;
	private JTextField textFCodigoCita;
	private JTextField textFFecha;
	private JTextField textField;
	private JTextField textFConsultorio;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Agenda frame = new Agenda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Agenda() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 775, 675);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnBuscar.setBounds(482, 103, 130, 30);
		contentPane.add(btnBuscar);
		
		JLabel lblNewLabel = new JLabel("AGENDA");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 28));
		lblNewLabel.setBounds(10, 22, 129, 66);
		contentPane.add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBackground(new Color(0, 0, 0));
		separator.setBounds(10, 86, 617, 2);
		contentPane.add(separator);
		
		JLabel lblNewLabel_1 = new JLabel("Odontologo");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(10, 110, 178, 18);
		contentPane.add(lblNewLabel_1);
		
		textFOdontologo = new JTextField();
		textFOdontologo.setFont(new Font("Tahoma", Font.PLAIN, 10));
		textFOdontologo.setBounds(156, 112, 173, 20);
		contentPane.add(textFOdontologo);
		textFOdontologo.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Paciente");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_2.setBounds(10, 140, 178, 18);
		contentPane.add(lblNewLabel_2);
		
		textFPaciente = new JTextField();
		textFPaciente.setFont(new Font("Tahoma", Font.PLAIN, 10));
		textFPaciente.setColumns(10);
		textFPaciente.setBounds(156, 140, 173, 20);
		contentPane.add(textFPaciente);
		
		JLabel lblNewLabel_3 = new JLabel("Codigo Cita");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_3.setBounds(10, 170, 178, 18);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Fecha");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4.setBounds(10, 200, 178, 18);
		contentPane.add(lblNewLabel_4);
		
		textFCodigoCita = new JTextField();
		textFCodigoCita.setFont(new Font("Tahoma", Font.PLAIN, 10));
		textFCodigoCita.setColumns(10);
		textFCodigoCita.setBounds(156, 200, 173, 20);
		contentPane.add(textFCodigoCita);
		
		textFFecha = new JTextField();
		textFFecha.setFont(new Font("Tahoma", Font.PLAIN, 10));
		textFFecha.setColumns(10);
		textFFecha.setBounds(156, 170, 173, 20);
		contentPane.add(textFFecha);
		
		JLabel lblNewLabel_4_1 = new JLabel("Hora");
		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4_1.setBounds(10, 230, 178, 18);
		contentPane.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("Consultorio");
		lblNewLabel_4_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4_1_1.setBounds(10, 260, 178, 18);
		contentPane.add(lblNewLabel_4_1_1);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 10));
		textField.setColumns(10);
		textField.setBounds(156, 230, 173, 20);
		contentPane.add(textField);
		
		textFConsultorio = new JTextField();
		textFConsultorio.setFont(new Font("Tahoma", Font.PLAIN, 10));
		textFConsultorio.setColumns(10);
		textFConsultorio.setBounds(156, 260, 173, 20);
		contentPane.add(textFConsultorio);
		
		JButton btnCrear = new JButton("Agendar");
		btnCrear.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnCrear.setBounds(67, 311, 130, 30);
		contentPane.add(btnCrear);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnConsultar.setBounds(267, 311, 130, 30);
		contentPane.add(btnConsultar);
	}
}
