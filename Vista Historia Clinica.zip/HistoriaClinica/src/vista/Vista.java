package vista;

import modelo.dto.HistoriaCliniDTO;
import java.util.List;

public class VistaHistoriaClinica {
    public void mostrarHistoriaClini(HistoriaClinicaDTO historiaClini) {
        System.out.println("Número Consecutivo: " + historiaClini.getNumeroConsecutivo());
        System.out.println("Paciente: " + historiaClini.getPaciente());
        System.out.println("Odontólogo: " + historiaClini.getOdontologo());
        System.out.println("Apertura: " + historiaClini.getApertura());
        System.out.println("Antecedentes: " + historiaClini.getAntecedentes());
        System.out.println("Evaluación Odontológica: " + historiaClini.getEvaluacionOdontologica());
        System.out.println("-------------------------------");
    }

    public void mostrarTodasLasHistorias(List<HistoriaClinicaDTO> historias) {
        for (HistoriaClinicaDTO historia : historias) {
            mostrarHistoriaClini(historia);
        }
    }

	public void mostrarTodasLasHistorias1(List<HistoriaClinicaDTO> historias) {
		// TODO Auto-generated method stub
		
	}
}
