package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JScrollBar;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

public class Vist extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFIdentificacion;
	private JTextField textFNombre;
	private JTextField textFApellido;
	private JTextField textFDireccion;
	private JTextField textFTelefono;
	private JTextField textFCelular;
	private JTextField textFCiudad;
	private JTextField textFEmail;
	private JTextField textFFNacimiento;
	private JTextField textFLNacimiento;
	private JTextField textFGenero;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Vista frame = new Vista();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Vist() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 775, 675);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Historia Clinica");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(10, 11, 196, 19);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Identificacion: ");
		lblNewLabel_1.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(10, 42, 106, 19);
		contentPane.add(lblNewLabel_1);
		
		textFIdentificacion = new JTextField();
		textFIdentificacion.setBounds(149, 41, 173, 20);
		contentPane.add(textFIdentificacion);
		textFIdentificacion.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 72, 739, 2);
		contentPane.add(separator);
		
		JButton btnFBuscar = new JButton("BUSCAR");
		btnFBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnFBuscar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnFBuscar.setBackground(new Color(255, 255, 255));
		btnFBuscar.setBounds(619, 34, 130, 30);
		contentPane.add(btnFBuscar);
		
		textFNombre = new JTextField();
		textFNombre.setBounds(149, 85, 173, 20);
		contentPane.add(textFNombre);
		textFNombre.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Nombre: ");
		lblNewLabel_2.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNewLabel_2.setBounds(10, 88, 65, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Apellido:");
		lblNewLabel_3.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNewLabel_3.setBounds(453, 85, 65, 19);
		contentPane.add(lblNewLabel_3);
		
		textFApellido = new JTextField();
		textFApellido.setBounds(576, 85, 173, 20);
		contentPane.add(textFApellido);
		textFApellido.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Direccion:");
		lblNewLabel_4.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNewLabel_4.setBounds(10, 118, 84, 14);
		contentPane.add(lblNewLabel_4);
		
		textFDireccion = new JTextField();
		textFDireccion.setBounds(149, 116, 173, 20);
		contentPane.add(textFDireccion);
		textFDireccion.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Telefono:");
		lblNewLabel_5.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNewLabel_5.setBounds(453, 116, 65, 14);
		contentPane.add(lblNewLabel_5);
		
		textFTelefono = new JTextField();
		textFTelefono.setBounds(576, 116, 173, 20);
		contentPane.add(textFTelefono);
		textFTelefono.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Celular:");
		lblNewLabel_6.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNewLabel_6.setBounds(10, 149, 65, 14);
		contentPane.add(lblNewLabel_6);
		
		textFCelular = new JTextField();
		textFCelular.setBounds(149, 147, 173, 20);
		contentPane.add(textFCelular);
		textFCelular.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Ciudad: ");
		lblNewLabel_7.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNewLabel_7.setBounds(453, 147, 65, 14);
		contentPane.add(lblNewLabel_7);
		
		textFCiudad = new JTextField();
		textFCiudad.setBounds(576, 144, 173, 20);
		contentPane.add(textFCiudad);
		textFCiudad.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Email:");
		lblNewLabel_8.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNewLabel_8.setBounds(10, 180, 65, 14);
		contentPane.add(lblNewLabel_8);
		
		textFEmail = new JTextField();
		textFEmail.setBounds(149, 178, 173, 20);
		contentPane.add(textFEmail);
		textFEmail.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("F. Nacimiento:");
		lblNewLabel_9.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNewLabel_9.setBounds(463, 180, 116, 14);
		contentPane.add(lblNewLabel_9);
		
		textFFNacimiento = new JTextField();
		textFFNacimiento.setColumns(10);
		textFFNacimiento.setBounds(576, 174, 173, 20);
		contentPane.add(textFFNacimiento);
		
		JLabel lblNewLabel_9_1 = new JLabel("L. Nacimiento:");
		lblNewLabel_9_1.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNewLabel_9_1.setBounds(453, 208, 116, 14);
		contentPane.add(lblNewLabel_9_1);
		
		textFLNacimiento = new JTextField();
		textFLNacimiento.setColumns(10);
		textFLNacimiento.setBounds(576, 205, 173, 20);
		contentPane.add(textFLNacimiento);
		
		JLabel lblNewLabel_8_1 = new JLabel("Genero:");
		lblNewLabel_8_1.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNewLabel_8_1.setBounds(10, 211, 65, 14);
		contentPane.add(lblNewLabel_8_1);
		
		textFGenero = new JTextField();
		textFGenero.setColumns(10);
		textFGenero.setBounds(149, 208, 173, 20);
		contentPane.add(textFGenero);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 241, 739, 18);
		contentPane.add(separator_1);
		
		JButton btnCrear = new JButton("CREAR");
		btnCrear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnCrear.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnCrear.setBackground(Color.WHITE);
		btnCrear.setBounds(74, 257, 130, 30);
		contentPane.add(btnCrear);
		
		JButton btnFBuscar_1_1 = new JButton("BUSCAR");
		btnFBuscar_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnFBuscar_1_1.setBackground(Color.WHITE);
		btnFBuscar_1_1.setBounds(235, 257, 130, 30);
		contentPane.add(btnFBuscar_1_1);
		
		JButton btnFModificar = new JButton("MODIFICAR");
		btnFModificar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnFModificar.setBackground(Color.WHITE);
		btnFModificar.setBounds(393, 257, 130, 30);
		contentPane.add(btnFModificar);
		
		JButton btnFEliminar = new JButton("ELIMINAR");
		btnFEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnFEliminar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnFEliminar.setBackground(Color.WHITE);
		btnFEliminar.setBounds(552, 257, 130, 30);
		contentPane.add(btnFEliminar);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"IDENTIFICACION", "NOMBRE", "APELLIDO", "DIRECCION", "CIUDAD", "TELEFONO", "CELULAR", "EMAIL", "F.NACIMIENTO", "L.NACIMIENTO", "GENERO"},
				{null, null, null, null, null, null, null, null, null, null, null},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		table.getColumnModel().getColumn(0).setMaxWidth(2147483646);
		table.setBounds(10, 298, 739, 30);
		contentPane.add(table);
	}
}
