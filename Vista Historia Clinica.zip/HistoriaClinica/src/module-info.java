/**
 * 
 */
/**
 * 
 */
module HistoriaClinica {
	requires java.desktop;
}