package controlador;

import modelo.dao.HistoriaCliniDao;
import modelo.dto.HistoriaCliniDTO;
import vista.VistaHistoriaClini;
import java.util.List;

public class ControllerHistoriaClinic {
    private VistaHistoriaClini vista;
    private HistoriaCliniDao modelo;

    public ControllerHistoriaClinic(VistaHistoriaClini vista) {
        this.vista = vista;
        this.modelo = new HistoriaCliniDao();
    }

    public boolean agregarHistoriaClini(HistoriaCliniDTO historiaClini) {
        return modelo.create(historiaClini);
    }

    public HistoriaCliniDTO obtenerHistoriaClini(int numeroConsecutivo) {
        return modelo.read(numeroConsecutivo);
    }

    public boolean actualizarHistoriaClini(HistoriaCliniDTO historiaClini) {
        return modelo.update(historiaClini);
    }

    public void mostrarTodasLasHistorias() {
        List<HistoriaCliniDTO> historias = modelo.consultarTodos();
        vista.mostrarTodasLasHistorias(historias);
    }
}
