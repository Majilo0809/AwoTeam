package modelo.dto;

public class HistoriaCliniDTO {
    private int numeroConsecutivo;
    private String paciente;
    private String odontologo;
    private String apertura;
    private String antecedentes;
    private String evaluacionOdontologica;

    ///////// Constructor
    public HistoriaCliniDTO(int numeroConsecutivo, String paciente, String odontologo, 
                              String apertura, String antecedentes, String evaluacionOdontologica) {
        this.numeroConsecutivo = numeroConsecutivo;
        this.paciente = paciente;
        this.odontologo = odontologo;
        this.apertura = apertura;
        this.antecedentes = antecedentes;
        this.evaluacionOdontologica = evaluacionOdontologica;
    }

    // Inyectar a lo diablo
    public int getNumeroConsecutivo() {
        return numeroConsecutivo;
    }

    public void setNumeroConsecutivo(int numeroConsecutivo) {
        this.numeroConsecutivo = numeroConsecutivo;
    }

    public String getPaciente() {
        return paciente;
    }

    public void setPaciente(String paciente) {
        this.paciente = paciente;
    }

    public String getOdontologo() {
        return odontologo;
    }

    public void setOdontologo(String odontologo) {
        this.odontologo = odontologo;
    }

    public String getApertura() {
        return apertura;
    }

    public void setApertura(String apertura) {
        this.apertura = apertura;
    }

    public String getAntecedentes() {
        return antecedentes;
    }

    public void setAntecedentes(String antecedentes) {
        this.antecedentes = antecedentes;
    }

    public String getEvaluacionOdontologica() {
        return evaluacionOdontologica;
    }

    public void setEvaluacionOdontologica(String evaluacionOdontologica) {
        this.evaluacionOdontologica = evaluacionOdontologica;
    }
}
