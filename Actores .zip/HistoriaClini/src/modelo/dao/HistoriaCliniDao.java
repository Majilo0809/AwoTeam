package modelo.dao;

import modelo.dto.HistoriaCliniDTO;
import java.util.ArrayList;
import java.util.List;

public class HistoriaCliniDao {
    private List<HistoriaCliniDTO> database = new ArrayList<>();

    public boolean create(HistoriaCliniDTO historiaClini) {
        return database.add(historiaClini);
    }

    public HistoriaCliniDTO read(int numeroConsecutivo) {
        for (HistoriaCliniDTO hc : database) {
            if (hc.getNumeroConsecutivo() == numeroConsecutivo) {
                return hc;
            }
        }
        return null;
    }

    public boolean update(HistoriaCliniDTO historiaClini) {
        for (int i = 0; i < database.size(); i++) {
            if (database.get(i).getNumeroConsecutivo() == historiaClini.getNumeroConsecutivo()) {
                database.set(i, historiaClini);
                return true;
            }
        }
        return false;
    }

    public List<HistoriaCliniDTO> consultarTodos() {
        return new ArrayList<>(database);
    }
    // no c, solo decia que reenombrar y crear un metodo y dejo de cometer los errores
	public List<HistoriaCliniDTO> consultarTodos1() {
		// TODO Auto-generated method stub
		return null;
	}
}
