package vista;

import modelo.dto.HistoriaCliniDTO;
import java.util.List;

public class VistaHistoriaClini {
    public void mostrarHistoriaClini(HistoriaCliniDTO historiaClini) {
        System.out.println("Número Consecutivo: " + historiaClini.getNumeroConsecutivo());
        System.out.println("Paciente: " + historiaClini.getPaciente());
        System.out.println("Odontólogo: " + historiaClini.getOdontologo());
        System.out.println("Apertura: " + historiaClini.getApertura());
        System.out.println("Antecedentes: " + historiaClini.getAntecedentes());
        System.out.println("Evaluación Odontológica: " + historiaClini.getEvaluacionOdontologica());
        System.out.println("-------------------------------");
    }

    public void mostrarTodasLasHistorias(List<HistoriaCliniDTO> historias) {
        for (HistoriaCliniDTO historia : historias) {
            mostrarHistoriaClini(historia);
        }
    }

	public void mostrarTodasLasHistorias1(List<HistoriaCliniDTO> historias) {
		// TODO Auto-generated method stub
		
	}
}
