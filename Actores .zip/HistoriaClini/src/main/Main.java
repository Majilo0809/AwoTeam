package main;

import controlador.ControllerHistoriaClini;
import vista.VistaHistoriaClini;

public class Main {
    public static void main(String[] args) {
        VistaHistoriaClini vista = new VistaHistoriaClini();
        ControllerHistoriaClini controlador = new ControllerHistoriaClini(vista);
        
       
        controlador.mostrarTodasLasHistorias();
    }
}
