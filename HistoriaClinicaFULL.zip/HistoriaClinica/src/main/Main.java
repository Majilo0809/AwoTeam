package main;

import vista.VistaHistoriaClinica;
import controlador.ControladorHistoriaClinica;

public class Main {
    public static void main(String[] args) {
        // Crear la vista
        VistaHistoriaClinica vista = new VistaHistoriaClinica();

        // Crear el controlador y asociarlo con la vista
        ControladorHistoriaClinica controladorHistoriaClinica = new ControladorHistoriaClinica(vista);

        // Hacer visible la vista
        vista.setVisible(true);
    }
}
