package modulo_dao;

import modulo_dto.HistoriaClinicaDTO;
import java.util.ArrayList;
import java.util.List;

public class HistoriaClinicaDAO {

    private List<HistoriaClinicaDTO> historiasClinicas;


    public HistoriaClinicaDAO() {
        this.historiasClinicas = new ArrayList<>();
    }


    public void agregarHistoriaClinica(HistoriaClinicaDTO historia) {
        historiasClinicas.add(historia);
        System.out.println("Historia clínica agregada con éxito.");
    }

    public List<HistoriaClinicaDTO> obtenerHistoriasClinicas() {
        return historiasClinicas;
    }

    public HistoriaClinicaDTO buscarHistoriaPorConsecutivo(int consecutivo) {
        for (HistoriaClinicaDTO historia : historiasClinicas) {
            if (historia.getNumeroConsecutivo() == consecutivo) {
                return historia;
            }
        }
        return null;
    }

    public boolean actualizarHistoriaClinica(HistoriaClinicaDTO historiaActualizada) {
        for (int i = 0; i < historiasClinicas.size(); i++) {
            if (historiasClinicas.get(i).getNumeroConsecutivo() == historiaActualizada.getNumeroConsecutivo()) {
                historiasClinicas.set(i, historiaActualizada);
                System.out.println("Historia clínica actualizada con éxito.");
                return true;
            }
        }
        return false; 
    }

    public boolean eliminarHistoriaClinica(int consecutivo) {
        for (int i = 0; i < historiasClinicas.size(); i++) {
            if (historiasClinicas.get(i).getNumeroConsecutivo() == consecutivo) {
                historiasClinicas.remove(i);
                System.out.println("Historia clínica eliminada con éxito.");
                return true;
            }
        }
        return false;
    }
}
