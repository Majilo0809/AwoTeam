/**
 * 
 */
/**
 * 
 */
module HistoriaClini {
	requires jakarta.annotation-api;
	requires org.eclipse.jface;
	requires org.eclipse.core.runtime;
	requires org.eclipse.osgi;
	requires com.ibm.icu;
	requires org.eclipse.equinox.registry;
	requires org.eclipse.core.commands;
	requires org.eclipse.ui.forms;
	requires org.eclipse.ui.workbench;
	requires org.eclipse.text;
	requires org.eclipse.e4.ui.di;
	requires org.eclipse.swt.win32.win32.x86_64;
	requires org.eclipse.equinox.common;
	requires org.eclipse.jface.text;
	requires jakarta.annotation-api;
	requires java.desktop;
}