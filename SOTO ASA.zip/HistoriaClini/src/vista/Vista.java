package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JScrollBar;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.Color;

public class Vista extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFIdentificacion;
	private JTextField textFNombre;
	private JTextField textFApellido;
	private JTextField textFDireccion;
	private JTextField textFTelefono;
	private JTextField textFCelular;
	private JTextField textFCiudad;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Vista frame = new Vista();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Vista() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Historia Clinica");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(10, 11, 196, 19);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Identificacion: ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(10, 42, 84, 19);
		contentPane.add(lblNewLabel_1);
		
		JScrollBar scrollBar = new JScrollBar();
		scrollBar.setBounds(417, 11, 17, 48);
		contentPane.add(scrollBar);
		
		textFIdentificacion = new JTextField();
		textFIdentificacion.setBounds(99, 42, 126, 20);
		contentPane.add(textFIdentificacion);
		textFIdentificacion.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 72, 402, 2);
		contentPane.add(separator);
		
		JButton btnConfirmar = new JButton("CONFIRMAR");
		btnConfirmar.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnConfirmar.setBackground(new Color(0, 0, 0));
		btnConfirmar.setBounds(299, 41, 108, 23);
		contentPane.add(btnConfirmar);
		
		textFNombre = new JTextField();
		textFNombre.setBounds(99, 85, 126, 20);
		contentPane.add(textFNombre);
		textFNombre.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Nombre: ");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_2.setBounds(10, 88, 65, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Apellido:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_3.setBounds(235, 88, 65, 14);
		contentPane.add(lblNewLabel_3);
		
		textFApellido = new JTextField();
		textFApellido.setBounds(299, 85, 108, 20);
		contentPane.add(textFApellido);
		textFApellido.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Direccion:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_4.setBounds(10, 118, 65, 14);
		contentPane.add(lblNewLabel_4);
		
		textFDireccion = new JTextField();
		textFDireccion.setBounds(99, 116, 126, 20);
		contentPane.add(textFDireccion);
		textFDireccion.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Telefono:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_5.setBounds(235, 119, 65, 14);
		contentPane.add(lblNewLabel_5);
		
		textFTelefono = new JTextField();
		textFTelefono.setBounds(299, 116, 108, 20);
		contentPane.add(textFTelefono);
		textFTelefono.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Celular:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_6.setBounds(10, 149, 46, 14);
		contentPane.add(lblNewLabel_6);
		
		textFCelular = new JTextField();
		textFCelular.setBounds(99, 147, 126, 20);
		contentPane.add(textFCelular);
		textFCelular.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Ciudad: ");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_7.setBounds(235, 150, 65, 14);
		contentPane.add(lblNewLabel_7);
		
		textFCiudad = new JTextField();
		textFCiudad.setBounds(299, 144, 108, 20);
		contentPane.add(textFCiudad);
		textFCiudad.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Email:");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_8.setBounds(10, 180, 46, 14);
		contentPane.add(lblNewLabel_8);
		
		textField = new JTextField();
		textField.setBounds(99, 178, 126, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("F. Nacimiento:");
		lblNewLabel_9.setBounds(235, 181, 65, 14);
		contentPane.add(lblNewLabel_9);
	}
}
