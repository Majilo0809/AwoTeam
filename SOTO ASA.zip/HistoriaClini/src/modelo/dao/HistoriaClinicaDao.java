package modelo.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import modelo.dto.Cita;

public class HistoriaClinicaDao {
	private ArrayList<HistoriaClinicaDao> lista;
	private ObjectInputStream entrada;
	private ObjectOutputStream salida;
	private String archivo;
	
	public HistoriaClinicaDao() {
		this.archivo = "cita";
		File file = new File(archivo);
			if (file.isFile()) {				
				try {
					this.entrada = new ObjectInputStream(new FileInputStream(archivo));
					this.lista = (ArrayList<HistoriaClinicaDao>) entrada.readObject();
					this.entrada.close();
				} catch (Exception e) {
					System.out.println(e.getMessage());
					guardar();
				}	
			} else {
				lista = new ArrayList<>();
			}
	}
	
	//Guarda en la capa de persistencia la lista
	private void guardar() {
		try {
			this.salida = new ObjectOutputStream(new FileOutputStream(archivo));
			this.salida.writeObject(lista);
			this.salida.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public boolean create(HistoriaClinicaDao historiaClinica) {
		lista.add(historiaClinica);
		guardar();
		return true;
	}
	
	public HistoriaClinicaDao read(int codigo) {
		for (HistoriaClinicaDao historiaClinica : lista) {
			if (historiaClinica.getCodigoHistoriaClinicaDao() == codigo) {
				return historiaClinica;
			}
		}
		return null;
	}
	
	private int getCodigoHistoriaClinicaDao() {
		// TODO Auto-generated method stub
		return 0;
	}

	public HistoriaClinicaDao update(int index, HistoriaClinicaDao historiaClinica) {
		lista.set(index, historiaClinica);
		guardar();		
		return historiaClinica;
	}
	
	public boolean delete(HistoriaClinicaDao historiaClinica) {
		lista.remove(historiaClinica);
		guardar();
		return true;
	}
	
	public ArrayList<HistoriaClinicaDao> readAll(){
		return lista;
	}
	
	public int buscarIndex(HistoriaClinicaDao historiaClinica) {
		return lista.indexOf(historiaClinica);
	}
	
}

	
	