package modulo_dao;

import modulo_dto.UsuarioDTO;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    private static List<UsuarioDTO> pacientes = new ArrayList<>();
    private static List<UsuarioDTO> odontologos = new ArrayList<>();
    private static List<UsuarioDTO> auxiliares = new ArrayList<>();
    private static List<UsuarioDTO> administradores = new ArrayList<>();

    public UsuarioDAO() {
        if (pacientes.isEmpty()) {
            pacientes.add(new UsuarioDTO("1031652466", "Angel", "Robles", "Cll 51B 36-30", "3038517", "3138996960", "Bogota", "angeljesusaraque@hotmail.com", "11 Mayo 2006", "Masculino", "San Cristobal Sur", "Paciente"));
            odontologos.add(new UsuarioDTO("1029384756", "Carlos", "Gómez", "Cll 10A 20-15", "3001234567", "3207654321", "Medellín", "carlos.gomez@odontologo.com", "15 Enero 1985", "Masculino", "Medellín", "Odontologo"));
            auxiliares.add(new UsuarioDTO("1098765432", "Laura", "Martínez", "Cll 50 45-20", "3012345678", "3189876543", "Cali", "laura.martinez@auxiliar.com", "20 Noviembre 1990", "Femenino", "Cali", "Auxiliar"));
            administradores.add(new UsuarioDTO("1122334455", "Sofía", "Rodríguez", "Av. Principal 150", "3023456789", "3158765432", "Bogotá", "sofia.rodriguez@admin.com", "10 Julio 1982", "Femenino", "Bogotá", "Administrador"));
        }
    }


    public List<UsuarioDTO> buscarUsuariosPorRol(String rol) {
        List<UsuarioDTO> resultado = new ArrayList<>();
        switch (rol) {
            case "Paciente":
                resultado.addAll(pacientes);
                break;
            case "Odontologo":
                resultado.addAll(odontologos);
                break;
            case "Auxiliar":
                resultado.addAll(auxiliares);
                break;
            case "Administrador":
                resultado.addAll(administradores);
                break;
        }
        return resultado;
    }

    // Buscar el usuario pai
    public UsuarioDTO buscarUsuarioPorRolYIdentificacion(String rol, String identificacion) {
        for (UsuarioDTO usuario : buscarUsuariosPorRol(rol)) {
            if (usuario.getIdentificacion().equals(identificacion)) {
                return usuario;
            }
        }
        return null;  // Si no se encuentra yuca null
    }

    // Agrega parceritos
    public void agregarUsuario(UsuarioDTO usuario) {
        switch (usuario.getRol()) {
            case "Paciente":
                pacientes.add(usuario);
                break;
            case "Odontologo":
                odontologos.add(usuario);
                break;
            case "Auxiliar":
                auxiliares.add(usuario);
                break;
            case "Administrador":
                administradores.add(usuario);
                break;
        }
    }
}
