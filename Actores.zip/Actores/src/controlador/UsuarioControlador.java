package controlador;

import modulo_dao.UsuarioDAO;
import modulo_dto.UsuarioDTO;
import java.util.ArrayList;
import java.util.List;

public class UsuarioControlador {

    private UsuarioDAO usuarioDAO;

    public UsuarioControlador() {
        usuarioDAO = new UsuarioDAO(); 
    }

    // buscar un usuario por rol e id
    public UsuarioDTO buscarUsuarioPorRolYIdentificacion(String rol, String identificacion) {
        return usuarioDAO.buscarUsuarioPorRolYIdentificacion(rol, identificacion);
    }

    // agregar un nuevo socito
    public void agregarUsuario(UsuarioDTO usuario) {
        usuarioDAO.agregarUsuario(usuario);
    }

    //buscar todos los usuarios de un rol específico
    public List<UsuarioDTO> buscarUsuariosPorRol(String rol) {
        return usuarioDAO.buscarUsuariosPorRol(rol);
    }

    // Método para listar todos los usuarios, sin importar su rol
    public List<UsuarioDTO> listarTodosUsuarios() {
        List<UsuarioDTO> todosUsuarios = new ArrayList<>();
        todosUsuarios.addAll(usuarioDAO.buscarUsuariosPorRol("Paciente"));
        todosUsuarios.addAll(usuarioDAO.buscarUsuariosPorRol("Odontologo"));
        todosUsuarios.addAll(usuarioDAO.buscarUsuariosPorRol("Auxiliar"));
        todosUsuarios.addAll(usuarioDAO.buscarUsuariosPorRol("Administrador"));
        return todosUsuarios;
    }

    //eliminar un usuario por cedula
    public void eliminarUsuario(String identificacion) {
        usuarioDAO.eliminarUsuario(identificacion);
    }

    //actualizar los datos de un usuario ya- existente
    public void actualizarUsuario(UsuarioDTO usuario) {
        usuarioDAO.actualizarUsuario(usuario);
    }

    //verificar si un usuario ya existe mi perrito
    public boolean existeUsuario(String rol, String identificacion) {
        UsuarioDTO usuario = buscarUsuarioPorRolYIdentificacion(rol, identificacion);
        return usuario != null;
    }
}

