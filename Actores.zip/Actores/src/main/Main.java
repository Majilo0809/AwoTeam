package main;

import vistaUsuarioVista;

public class Main {
    public static void main(String[] args) {
        UsuarioVista vista = new UsuarioVista();
        vista.setVisible(true);
    }
}
